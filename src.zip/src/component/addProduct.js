import React, { Component } from 'react';
import ReactDOM from 'react-dom';
// import 'bootstrap/dist/css/bootstrap.min.css';


class Add extends Component {
    bangDiem=[];
    constructor(props){
        super(props);
        this.state={
          name:null,
          price:null,
          tiltle:null,
          image: null,
          discount:null
        };
        
        this.handleChange = this.watch.bind(this);
        this.handleSubmit = this.mySubmitHandler.bind(this);
        this.handleSubmit = this.myChangeHandler.bind(this);
      }
      mySubmitHandler =(event) => {
        event.preventDefault();
            this.bangDiem.push(this.state);
            localStorage.setItem("bangdiem", JSON.stringify(this.bangDiem));
            
      }
      watch =() => {
        
    }
    
      myChangeHandler=(event)=>{
        let nam=event.target.name;
        let val=event.target.value;
        // alert(nam.indexOf("hobbie"));
        // if(nam.indexOf("hobbie")!=-1){
        //     if(document.getElementById(nam).checked==true){
        //         let hop=this.state.hobbies;
        //         hop.push(val);
        //         this.setState({hobbies:hop});
        //     }
        // }
        this.setState({[nam]:val})
      }
    render() {
        return (
            <div>
                
                <form style={{width:"70%", marginLeft:"auto",marginRight:"auto"}} onSubmit={this.mySubmitHandler}>
                    <div className="form-group">
                        <label for="email">Tên sản phẩm:</label>
                        <input type="text" className="form-control" name="name" onChange={this.myChangeHandler}></input>
                    </div>
                    <div className="form-group">
                        <label for="pwd">Giá sản phẩm</label>
                        <input type="number" className="form-control" min="0" name="price" onChange={this.myChangeHandler}></input>
                    </div>
                    <div className="form-group">
                        <label for="pwd">Mô tả sản phẩm</label>
                        <input type="text" className="form-control" name="title" onChange={this.myChangeHandler}></input>
                    </div>
                    <div className="form-group">
                        <label for="pwd">Giảm giá</label>
                        <input type="number" className="form-control" min="0" max="100" name="discount" onChange={this.myChangeHandler}></input>
                    </div>
                    <div className="form-group">
                        <label for="pwd">Hình ảnh sản phẩm</label>
                        <input type="file" className="form-control" name="image" onChange={this.myChangeHandler}></input>
                    </div>
                    
                    <button type="submit" className="btn btn-primary" onClick={this.watch}>Submit</button>
                </form>
            </div>
        );
    }
}

export default Add;